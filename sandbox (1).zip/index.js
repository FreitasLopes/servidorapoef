const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const bodyParser = require("body-parser");
const sqlite3 = require("sqlite3");
const app = express();

// Definindo uma chave secreta para o JWT
const tokenSecret = "T4#P90&876E454VDW##5678Pr$$#";

// Conectando ao banco de dados SQLite
const banco = new sqlite3.Database("BancoDadosAppoef.db");

// Configurando middleware para processamento de JSON
app.use(bodyParser.json());

// Função para cadastrar um usuário
function postCadastrarUsuario(req, res) {
  const usuario = req.body.usuario;
  const senha = req.body.senha;

  // Verifica se o usuário e a senha foram fornecidos
  if (!usuario || !senha) {
    return res.status(400).json({
      success: false,
      message: "Usuário e senha são obrigatórios.",
    });
  }

  // Verifica se o usuário já existe no banco de dados
  banco.get(
    `SELECT * FROM Login WHERE usuario = ?`,
    [usuario],
    function (err, row) {
      if (err) {
        console.log("Erro ao verificar usuário:", err);
        return res.status(500).json({
          success: false,
          message: "Erro na verificação do usuário.",
        });
      }

      if (row) {
        // Usuário já existe
        return res.status(400).json({
          success: false,
          message: "Usuário já existe.",
        });
      }

      // Criptografa a senha antes de armazená-la
      const hashedPassword = bcrypt.hashSync(senha, 10);
      console.log("Senha criptografada:", hashedPassword); // Exibe a senha criptografada

      // Insere o novo usuário com a senha criptografada no banco
      banco.run(
        `INSERT INTO Login (usuario, senha) VALUES (?, ?)`,
        [usuario, hashedPassword],
        function (err) {
          if (err) {
            console.log("Erro ao inserir usuário no banco de dados:", err);
            return res.status(500).json({
              success: false,
              message: "Erro ao criar usuário.",
            });
          } else {
            console.log("Usuário cadastrado com sucesso! ID:", this.lastID);
            res.status(201).json({
              success: true,
              message: "Usuário cadastrado com sucesso!",
              idLogin: this.lastID,
            });
          }
        }
      );
    }
  );
}

function postCriaLogin(req, res) {
  const usuario = req.body.usuario;
  const senha = req.body.senha;

  if (!usuario || !senha) {
    return res.status(400).json({
      success: false,
      message: "Usuário e senha são obrigatórios.",
    });
  }

  console.log("Tentando logar com:", usuario); // Log da tentativa de login

  banco.get(
    `SELECT * FROM Login WHERE usuario = ?`,
    [usuario],
    function (err, row) {
      if (err) {
        console.error("Erro ao buscar usuário:", err);
        return res.status(500).json({
          success: false,
          message: "Erro ao verificar usuário.",
        });
      }

      console.log("Usuário encontrado:", row); // Log do usuário encontrado

      if (!row) {
        return res.status(401).json({
          success: false,
          message: "Credenciais inválidas.",
        });
      }

      if (!bcrypt.compareSync(senha, row.senha)) {
        return res.status(401).json({
          success: false,
          message: "Credenciais inválidas.",
        });
      }

      const payload = { idLogin: row.idLogin, usuario: row.usuario };
      const token = jwt.sign(payload, tokenSecret, { expiresIn: "1h" });

      return res.status(200).json({
        success: true,
        message: "Login realizado com sucesso",
        token: token,
        idLogin: row.idLogin,
      });
    }
  );
}

app.get("/usuarios", (req, res) => {
  banco.all(`SELECT * FROM Login`, [], (err, rows) => {
    if (err) {
      console.error("Erro ao buscar usuários:", err);
      return res
        .status(500)
        .json({ success: false, message: "Erro ao buscar usuários." });
    }
    return res.status(200).json({ success: true, users: rows });
  });
});

// Rota para cadastro de usuário
app.post("/cadastrar", postCadastrarUsuario);
// Rota para login
app.post("/login", postCriaLogin);
app.post("/usuarios");

// Inicialização do servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
