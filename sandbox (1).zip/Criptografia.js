const crypto = require("crypto");

class Criptografia {
  static algoritmo = "aes-256-cbc"; // Altere conforme necessário
  static chave = crypto.randomBytes(32); // Chave de 256 bits
  static iv = crypto.randomBytes(16); // Vetor de inicialização

  static criptografar(texto) {
    const cipher = crypto.createCipheriv(this.algoritmo, this.chave, this.iv);
    let resultado = cipher.update(texto, "utf8", "hex");
    resultado += cipher.final("hex");
    return resultado;
  }

  static descriptografar(texto) {
    const decipher = crypto.createDecipheriv(this.algoritmo, this.chave, this.iv);
    let resultado = decipher.update(texto, "hex", "utf8");
    resultado += decipher.final("utf8");
    return resultado;
  }
}

module.exports = Criptografia;
